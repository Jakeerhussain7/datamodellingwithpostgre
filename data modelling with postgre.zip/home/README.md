Project Purpose :
     In this Postgres database is to help Sparkify to optimize queries on song play analysis,by using log and song datasets and format will be in JSON format.

DATA BASE SCHEMA :
      By using the song and log datasets, a star schema is created for queries on song play analysis.
      FACT TABLE:
           songplays - records in log data associated with song plays i.e. records with page NextSong
           Columns will be ongplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent
      DIMENSION TABLE:
          1.users - users in the app
            Columns will be user_id, first_name, last_name, gender, level
          2.songs - songs in music database
            Columns will be song_id, title, artist_id, year, duration
          3.artists - artists in music database
             Columns will be artist_id, name, location, latitude, longitude
          4.time - timestamps of records in songplays broken down into specific units
             Columns will be start_time, hour, day, week, month, year, weekday

Python scripts: 
     etl.pynb: file is used for ETL process. 
     etl.py: is used to build ETL processes which will read JSON every file contained in data folder. 
     sql_queries.py is useed for writing SQL statements and to resolve query and finally 
     test.ipynb: is used for checking results  

EXPLANATION:
     To create the sparkifydb database, i used to run create_tables.py from the terminal. Then run test.ipynb to confirm the creation of your tables with the correct columns.Finally, i used to run test.ipynb to confirm your records were successfully inserted into each table.